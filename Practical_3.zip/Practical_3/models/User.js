const mongoose = require("mongoose");
const DATEONLY = require("mongoose-dateonly")(mongoose);
const Schema = mongoose.Schema;

const userSchema = new Schema({
  username: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  otp: {
    type: Number,
    required: true,
  },
  // otpExpiry: {
  //   type: DATEONLY,
  //   required: true,
  // },
});

module.exports = mongoose.model("User", userSchema);
