const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const serviceSchema = new Schema({
  s_name: {
    type: String,
    required: true,
  },
  v_no: {
    type: Number,
    required: true,
  }
});

module.exports = mongoose.model("Service", serviceSchema);
