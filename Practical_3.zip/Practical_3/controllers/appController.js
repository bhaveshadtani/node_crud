const bcrypt = require("bcryptjs");
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

const { validationResult } = require('express-validator');

const User = require("../models/User");
const Service = require("../models/service");
// const { getMaxListeners } = require("../models/User");

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'bhaveshadtani2001@gmail.com',
    pass: "ounjjuedqtzkosdh"
  }
});


const secterKey = "thisiskey";
var generateOTP = 0;

exports.landing_page = (req, res) => {
  res.render("landing");
};

exports.login_get = (req, res) => {

  res.render("login", {
    errors: "",
    oldInput: {
      email: "",
      password: ""
    },
    validationErrors: []
  });
};

exports.login_post = async (req, res) => {

  const { email, password } = req.body;
  const hasdPswd = await bcrypt.hash(password, 12);
  const errors = validationResult(req);

  // console.log(errors.array()[0].msg);
  if (!errors.isEmpty()) {
    return res.status(422).render('login', {
      errors: errors.array()[0].msg,
      validationErrors: errors.array()
    });
  }
  console.log("EMAIL :: ", email);

  

  User.findOne({ email: email }, function (err, docs) {
    if (docs) {
      console.log("USER IN : ", docs);
      console.log("user enter password : ", password);
      console.log("HASDPWD password : ", hasdPswd);

      const isMatch = bcrypt.compare(password, docs.password);

      if (isMatch) {
        const token = jwt.sign({ id: docs._id }, secterKey)
        res.cookie('token', token, {
          httpOnly: true,
        });

        generateOTP = Math.floor(Math.random() * 9999);
        console.log("OTP : ", generateOTP);

        function changeOTP() {
          generateOTP = 0;
        }

        setTimeout(changeOTP, 5 * 60 * 1000);

        transporter.sendMail({

          from: "bhaveshadtani2001@gmail.com",
          to: 'bhavesh.adtani@technomark.io',
          subject: "Login Verification",
          html: `<h3>Verification OTP : ${generateOTP}</h3>`

        })
          .then(() => {
            console.log("MAIL SENT");
            res.redirect("/verifyOTP");
          })
          .catch(err => { console.log("NOT SENT MAIL"); })
      }
    }
    else {
      console.log("EROR :: ", err)
    }
  });
};

// exports.register_get = (req, res) => {
//   res.render("register", {
//     errors: "",
//     oldInput: {
//       username: "",
//       email: "",
//       password: ""
//     },
//     validationErrors: []
//   });
// };



// var now = new Date(Date.now() + (5 * 60 * 1000));
// console.log("DATE :: :: ", now, " :: " , new Date());



// exports.register_post = async (req, res) => {
//   const { username, email, password } = req.body;
//   const errors = validationResult(req);
//   // console.log(errors.array()[0].msg);
//   if (!errors.isEmpty()) {
//     return res.status(422).render('register', {
//       errors: errors.array()[0].msg,
//       oldInput: {
//         username: username,
//         email: email,
//         password: req.body.password
//       },
//       validationErrors: errors.array()
//     });
//   }

//   generateOTP = Math.floor(Math.random() * 9999);
//   console.log("OTP :: ", generateOTP);

//   let user = await User.findOne({ email });

//   if (user) {
//     return res.redirect("/register");
//   }

//   const hasdPsw = await bcrypt.hash(password, 12);

// user = new User({
//   username,
//   email,
//   password: hasdPsw,
//   otp: generateOTP,
// });


//   user.save()
//     .then(() => {

//       console.log("email :: ", email)
//       transporter.sendMail({

//         from: "bhaveshadtani2001@gmail.com",
//         to: 'bhavesh.adtani@technomark.io',
//         subject: "Login Verification",
//         html: `<h3>Verification OTP : ${generateOTP}</h3>`

//       })
//         .then(() => {
//           console.log("MAIL SENT");
//           res.redirect("/verifyOTP");
//         })
//         .catch(err => { console.log("NOT SENT MAIL"); })
//     })


// };

exports.getVerify_OTP = (req, res) => {
  res.render("verifyOTP");
};

exports.postVerify_OTP = (req, res) => {

  if (generateOTP == req.body.verify_OTP) {
    res.render("dashboard");
  }
  else {
    console.log("POST OTP VERIFIY FAIL");
  }
};


exports.getAddService = (req, res) => {
  res.render("addService");
};

exports.postAddService = (req, res) => {

  var { s_name, v_no } = req.body;


  res.render("addService");

  // res.render("viewService",{
  //   pageTitle: "Add Service",
  //   s_name: s_name,
  //   v_no: v_no
  // });

  service = new Service({
    s_name,
    v_no,
    role: "admin"
  });

  service.save()
    .then(() => {
      console.log("SERVICE ADDED");

      transporter.sendMail({

        from: "bhaveshadtani2001@gmail.com",
        to: 'bhavesh.adtani@technomark.io',
        subject: "Service Added",
        html: `<h3>Vehical No : ${v_no}</h3>`

      })
        .then(() => {
          console.log("MAIL SENT");
          res.redirect("/verifyOTP");
        })
        .catch(err => { console.log("NOT SENT MAIL"); })

    })
    .catch(err => {
      console.log("SERVICE NOT ADDED :: ", err);
    });
};

exports.getViewService = (req, res) => {

  Service.find()
    .then(ress => {
      console.log("FIND RES :: ", res);
      res.render("viewService", {
        pageTitle: "View Service",
        rows: ress
      });
    })
};

exports.dashboard_get = (req, res) => {
  res.render("dashboard");
};

exports.logout_post = (req, res) => {
  res.clearCookie("token")
  res.redirect("/login");
};


exports.reset_passget = (req, res) => {

  res.render("forgot-password");
};

exports.reset_passpost = (req, res) => {
  const email = req.body.email;

  User.findOne({ email })
    .then(result => {
      res.redirect('/login');

      transporter.sendMail({
        from: "bhaveshadtani2001@gmail.com",
        to: 'bhavesh.adtani@technomark.io',
        subject: "Login Verification",
        html: `Click <a href=http://localhost:4000/new-password/${result._id}>here</a> to reset password`
      })
        .then(() => {
          console.log("MAIL SENT");
        })
        .catch(err => { console.log("MAIL NOT SENT") });
    })
    .catch(err => { console.log("RESET PWD ERROER :: ", err) });



  // if (!user) {
  //   return res.redirect("/login");
  // }
  // transporter.sendMail({

  //   from: "bhaveshadtani2001@gmail.com",
  //   to: "ckchavda077@gmail.com",
  //   subject: "Signup Success",
  //   html: `Click <a href=http://localhost:4000/new-password/${user._id}>here</a> to reset password`

  // })
  // res.redirect("/login");

};

exports.newpassget = (req, res) => {

  const id = req.params.id
  // console.log(id);


  res.render("new-password", {
    id
  });
};

exports.newpasspost = async (req, res) => {
  var id = req.body.id
  var new_pass = req.body.password
  // console.log(id);
  const hasdPsw = await bcrypt.hash(new_pass, 12);

  let user = await User.findOne({ _id: id });

  if (user) {
    user.password = hasdPsw
    user.save()
      .then(() => {
        // console.log(user);
        res.redirect("login");
      })
  }

};