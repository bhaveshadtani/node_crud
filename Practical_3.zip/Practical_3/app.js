const express = require("express");
// const session = require("express-session");
// const MongoDBStore = require("connect-mongodb-session")(session);
const config = require("config");
const cookieParser = require('cookie-parser');
const { check,body } = require('express-validator');

const appController = require("./controllers/appController");
const isAuth = require("./middleware/is-auth");
const connectDB = require("./config/db");
const mongoURI = config.get("mongoURI");

const app = express();
connectDB();

// const store = new MongoDBStore({
//   uri: mongoURI,
//   collection: "mySessions",
// });

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));

// app.use(
//   session({
//     secret: "secret",
//     resave: false,
//     saveUninitialized: false,
//     store: store,
//   })
// );

app.use(cookieParser());
// app.use(flash());

//=================== Routes
// Landing Page
app.get("/", appController.landing_page);

// Login Page
app.get("/login", appController.login_get);
app.post("/login", check('email').isEmail().withMessage('Please enter valid email.'),
body('password').isLength({min:5}).withMessage('Password atleast 5 characters'),
appController.login_post);

// Register Page
// app.get("/register", appController.register_get);
// app.post("/register", check('email').isEmail().withMessage('Please enter valid email.'),
//   body('username').isLength({min:5}).withMessage('Username is too small'),
//   body('password').isLength({min:5}).withMessage('Password atleast 5 characters'),
// appController.register_post);

// Dashboard Page
app.get("/dashboard",isAuth, appController.dashboard_get);

app.post("/logout",isAuth, appController.logout_post);

app.get("/forgot-password", appController.reset_passget);

app.post("/forgot-password", appController.reset_passpost);

app.get("/new-password/:id", appController.newpassget);

app.post("/new-pass", appController.newpasspost);

// OTP VERIFICATION GET
app.get("/verifyOTP", appController.getVerify_OTP);

// OTP VERIFICATION POST
app.post("/verifyOTP", appController.postVerify_OTP);

// ADD SERVICE GET
app.get("/addService", appController.getAddService);

// ADD SERVICE POST
app.post("/addService", appController.postAddService);

// VIEW SERVICE GET
app.get("/viewService", appController.getViewService);


app.listen(4000, console.log("App Running on http://localhost:4000"));
