const bcrypt = require("bcryptjs");
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

const { validationResult } = require('express-validator/check');

const User = require("../models/User");
// const { getMaxListeners } = require("../models/User");

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'digenmakwana22@gmail.com',
    pass: "cgszuxzhpddyyrab"
  }
});


const secterKey = "thisiskey";

exports.landing_page = (req, res) => {
  res.render("landing");
};

exports.login_get = (req, res) => {

  res.render("login", {
    errors: "",
    oldInput: {
      email: "",
      password: ""
    },
    validationErrors: []
  });
};

exports.login_post = async (req, res) => {
  const { email, password } = req.body;
  const errors = validationResult(req);
  // console.log(errors.array()[0].msg);
  if (!errors.isEmpty()) {
    return res.status(422).render('login', {
      errors: errors.array()[0].msg,
      oldInput: {
        email: email,
        password: password
      },
      validationErrors: errors.array()
    });
  }
  const user = await User.findOne({ email });
  if (!user) {
    return res.redirect("/login");
  }

  const isMatch = await bcrypt.compare(password, user.password);

  if (!isMatch) {
    return res.redirect("/login");
  }
  const token = jwt.sign({ id: user._id }, secterKey)
  res.cookie('token', token, {
    httpOnly: true,
    maxAge: 5 * 1000,
  });
  res.redirect("/dashboard");
};

exports.register_get = (req, res) => {
  res.render("register", {
    errors: "",
    oldInput: {
      username: "",
      email: "",
      password: ""
    },
    validationErrors: []
  });
};

exports.register_post = async (req, res) => {
  const { username, email, password } = req.body;
  const errors = validationResult(req);
  // console.log(errors.array()[0].msg);
  if (!errors.isEmpty()) {
    return res.status(422).render('register', {
      errors: errors.array()[0].msg,
      oldInput: {
        username: username,
        email: email,
        password: req.body.password
      },
      validationErrors: errors.array()
    });
  }

  let user = await User.findOne({ email });

  if (user) {
    return res.redirect("/register");
  }

  const hasdPsw = await bcrypt.hash(password, 12);

  user = new User({
    username,
    email,
    password: hasdPsw,
  });

  await user.save()
    .then(() => {

      console.log("email :: ", email)
      transporter.sendMail({

        from: "digenmakwana22@gmail.com",
        to: email,
        subject: "Signup Success",
        text: "Thank You for sign in",
        html: "<h1>TEST </h1>"

      })

    })
  res.redirect("/login");


};

exports.dashboard_get = (req, res) => {
  res.render("dashboard");
};

exports.logout_post = (req, res) => {
  res.clearCookie("token")
  res.redirect("/login");
};


exports.reset_passget = (req, res) => {

  res.render("otp-form");
};

exports.reset_passpost = async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ email });
  // console.log("user :: ", user._id);
  if (!user) {
    return res.redirect("/login");
  }
  transporter.sendMail({

    from: "digenmakwana22@gmail.com",
    to:"digen.makwana@technomark.io",
    subject: "Signup Success",
    text: "Thank You for sign in",
    html: `Click <a href=http://localhost:4000/new-password/${user._id}>here</a> to reset password`

  })
  res.redirect("/login");

};

exports.newpassget = (req, res) => {

  const id = req.params.id
  // console.log(id);


  res.render("new-password", { 
    id
  });
};

exports.newpasspost = async(req, res) => {
  var id= req.body.id
  var new_pass = req.body.password
  // console.log(id);
  const hasdPsw = await bcrypt.hash(new_pass, 12);

    let user = await User.findOne({ _id: id });

  if(user){
    user.password = hasdPsw
    user.save()
    .then(() => {
      // console.log(user);
      res.redirect("login");
    })
  }

};