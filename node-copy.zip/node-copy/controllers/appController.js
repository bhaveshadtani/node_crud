const bcrypt = require("bcryptjs");
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

const { validationResult } = require('express-validator/check');

const User = require("../models/User");
// const { getMaxListeners } = require("../models/User");

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'bhaveshadtani2001@gmail.com',
    pass: "ounjjuedqtzkosdh"
  }
});


const secterKey = "thisiskey";

exports.landing_page = (req, res) => {
  res.render("landing");
};

exports.login_get = (req, res) => {

  res.render("login", {
    errors: "",
    oldInput: {
      email: "",
      password: ""
    },
    validationErrors: []
  });
};

exports.login_post = async (req, res) => {
  const { email, password } = req.body;
  const errors = validationResult(req);
  // console.log(errors.array()[0].msg);
  if (!errors.isEmpty()) {
    return res.status(422).render('login', {
      errors: errors.array()[0].msg,
      oldInput: {
        email: email,
        password: password
      },
      validationErrors: errors.array()
    });
  }
  const user = await User.findOne({ email })
    .then(() => {


      return res.redirect("/login");
    })
    .catch(err => { console.log("Error in login :: ", err) })

  const isMatch = await bcrypt.compare(password, user.password);

  if (!isMatch) {
    return res.redirect("/login");
  }
  const token = jwt.sign({ id: user._id }, secterKey)
  res.cookie('token', token, {
    httpOnly: true,
    maxAge: 5 * 1000,
  });
  res.redirect("/dashboard");
};

exports.register_get = (req, res) => {
  res.render("register", {
    errors: "",
    oldInput: {
      username: "",
      email: "",
      password: ""
    },
    validationErrors: []
  });
};

let generateOTP = 0;

exports.register_post = async (req, res) => {
  const { username, email, password } = req.body;
  const errors = validationResult(req);
  // console.log(errors.array()[0].msg);
  if (!errors.isEmpty()) {
    return res.status(422).render('register', {
      errors: errors.array()[0].msg,
      oldInput: {
        username: username,
        email: email,
        password: req.body.password
      },
      validationErrors: errors.array()
    });
  }

  let user = await User.findOne({ email });

  if (user) {
    return res.redirect("/register");
  }

  const hasdPsw = await bcrypt.hash(password, 12);

  user = new User({
    username,
    email,
    password: hasdPsw,
  });


  generateOTP = Math.floor(Math.random() * 9999);
  console.log("OTP :: ", generateOTP);

  user.save()
    .then(() => {

      console.log("email :: ", email)
      transporter.sendMail({

        from: "bhaveshadtani2001@gmail.com",
        to: 'bhaveshadtani2001@gmail.com',
        subject: "Login Verification",
        html: `<h3>Verification OTP : ${generateOTP}</h3>`

      })
        .then(() => {
          console.log("MAIL SENT");
          res.redirect("/verifyOTP");
        })
        .catch(err => { console.log("NOT SENT MAIL"); })
    })


};

exports.getVerify_OTP = (req, res) => {
  res.render("verifyOTP");
};

exports.postVerify_OTP = (req, res) => {

  if (generateOTP == req.body.verify_OTP) {
    res.render("login", {
      errors: "",
      oldInput: {
        email: "",
        password: ""
      },
      validationErrors: []
    });
  }
  else {
    console.log("POST OTP VERIFIY FAIL");
  }
};

exports.dashboard_get = (req, res) => {
  res.render("dashboard");
};

exports.logout_post = (req, res) => {
  res.clearCookie("token")
  res.redirect("/login");
};


exports.reset_passget = (req, res) => {

  res.render("otp-form");
};

exports.reset_passpost = async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ email });
  // console.log("user :: ", user._id);
  if (!user) {
    return res.redirect("/login");
  }
  transporter.sendMail({

    from: "bhaveshadtani2001@gmail.com",
    to: "ckchavda077@gmail.com",
    subject: "Signup Success",
    text: "Thank You for sign in",
    html: `Click <a href=http://localhost:4000/new-password/${user._id}>here</a> to reset password`

  })
  res.redirect("/login");

};

exports.newpassget = (req, res) => {

  const id = req.params.id
  // console.log(id);


  res.render("new-password", {
    id
  });
};

exports.newpasspost = async (req, res) => {
  var id = req.body.id
  var new_pass = req.body.password
  // console.log(id);
  const hasdPsw = await bcrypt.hash(new_pass, 12);

  let user = await User.findOne({ _id: id });

  if (user) {
    user.password = hasdPsw
    user.save()
      .then(() => {
        // console.log(user);
        res.redirect("login");
      })
  }

};