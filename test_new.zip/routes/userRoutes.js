const express = require('express');

const userController = require('../controllers/userController');

const router = express.Router();

// ADMIN DASHBOARD
router.get('/', userController.getAdminDashboard);
router.get('/adminDashboard', userController.getAdminDashboard);

// CUSTOMER DASHBOARD
// router.get('/customerDashboard', userController.getCustomerDashboard);

// GET LOGIN
router.get('/login', userController.getLogin);

// POST LOGIN
router.post('/login', userController.postLogin);

// GET REGISTER
router.get('/register', userController.getRegister);

// POST REGISTER
router.post('/register', userController.postRegister);

// GET ADD CUSTOMER
router.get('/addCustomer', userController.getAddCustomer);

// POST ADD CUSTOMER
router.post('/addCustomer', userController.postAddCustomer);

// GET VIEW USER
router.get('/viewUser', userController.getViewUser);

// GET VIEW CUSTOMER
router.get('/viewCustomer', userController.getViewCustomer);

// GET VIEW SERVICE
// router.get('/viewService', userController.getViewService);


// GET EDIT USER
router.get('/editUser/:u_id', userController.getEditUser);

// POST EDIT USER
router.post('/editUser', userController.postEditUser);

// GET EDIT CUSTOMER
router.get('/editCustomer/:c_id', userController.getEditCustomer);

// POST EDIT CUSTOMER
router.post('/editCustomer', userController.postEditCustomer);

// GET EDIT SERVICE
router.get('/editService/:s_id', userController.getEditService);

// POST EDIT SERVICE
router.post('/editService', userController.postEditService);


// DELETE USER
router.post('/deleteUser', userController.postDeleteUser);

// DELETE CUSTOMER
router.post('/deleteCustomer', userController.postDeleteCustomer);

// DELETE SERVICE
router.post('/deleteService', userController.postDeleteService);

// ADMIN ADD USER

// GET ADD USER
router.get('/addUser', userController.getAddUser);

// POST ADD USER
router.post('/addUser', userController.postAddUser);


// //  DELETE CUSTOMER

// router.delete('/deleteCustomer', userController.deleteCustomer)




module.exports = router;