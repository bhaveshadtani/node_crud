const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const User = require('../models/user.js');
const Customer = require('../models/customer');

// GET ADMIN DASHBOARD
exports.getAdminDashboard = (req, res, next) => {
    res.render('adminDashboard', {
        pageTitle: "Admin Dashboard",
    });
};

// GET CUSTOMER DASHBOARD
exports.getCustomerDashboard = (req, res, next) => {
    res.render('customerDashboard', {
        pageTitle: "Customer Dashboard",
    });
};

// GET LOGIN
exports.getLogin = (req, res, next) => {
    res.render('login', {
        pageTitle: "Login",
    });
};

// POST LOGIN
exports.postLogin = (req, res, next) => {

    const { email, password } = req.body;

    User.findOne({ email: email, password: password })
        .then((ress) => {
            if (ress.email == email && ress.password == password) {
                if (ress.role == 'admin') {
                    res.render('adminDashboard', {
                        pageTitle: "Admin Dashboard",
                        // dashboard_Role: 'admin'
                    });
                }
                else {
                    res.render('customerDashboard', {
                        pageTitle: "Customer Dashboard",
                        // dashboard_Role: 'customer'
                    });
                }
            }
        })
        .catch(() => { res.redirect('/register'); })
};

// GET REGISTER
exports.getRegister = (req, res, next) => {
    res.render('register', {
        pageTitle: "Register",
    });
};

// POST REGISTER
exports.postRegister = (req, res, next) => {

    const data = { name, email, phone, password, dob, city } = req.body;
    const user = new User(data);

    user.save()
        .then((ress) => {
            res.render('login', {
                pageTitle: 'Login'
            });

            var transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: 'bhaveshadtani2001@gmail.com',
                    pass: 'ounjjuedqtzkosdh'
                }
            });

            var mailOptions = {
                from: 'bhaveshadtani2001@gmail.com',
                to: 'myfriend@yahoo.com',
                // to: 'bhavesh.adtani@technomark.io',
                subject: 'Verify Registration',
                text: 'Your registration has been successfully done!'
            };

            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    console.log(error);
                } else {
                    console.log('Email sent successfully!');
                }
            });
        })
        .catch((err) => { console.log("Register err :: ", err) })
};

// GET ADD CUSTOMER
exports.getAddCustomer = (req, res, next) => {

    User.find({ role: 'user' })
        .then((user) => {
            res.render('addCustomer', {
                pageTitle: "Add Customer",
                users: user
            });
        })
        .catch((err) => { console.log("Get add customer Error :: ", err) })
};

// POST ADD CUSTOMER
exports.postAddCustomer = (req, res, next) => {

    const { name, email, phone, dob, city, userId } = req.body;

    var customer = new Customer({ name, email, phone, dob, city, userId });

    customer.save()
        .then(result => {
            User.find({ role: 'user' })
                .then((user) => {
                    res.render('addCustomer', {
                        pageTitle: "Add Customer",
                        users: user
                    });
                })
                .catch((err) => { console.log("Get post customer Error :: ", err) })
        })
        .catch(err => { console.log("ERROR :: ", err); })

};

// GET VIEW USER
exports.getViewUser = (req, res, next) => {

    User.find()
        .then((userResult) => {
            res.render('viewUser', {
                pageTitle: "View User",
                userData: userResult,
            });
        })
        .catch((err) => { console.log("get view user err :: ", err); });
};

// GET VIEW CUSTOMER
exports.getViewCustomer = (req, res, next) => {

    Customer.find()
        .then((customerResult) => {

            // customerResult.forEach((customer) => {
            //     console.log("idid :::: ", customer.userId);
            // })

            User.findOne({ _id: customerResult.userId })
                .then((unm) => {
                    res.render('viewCustomer', {
                        pageTitle: "View Customer",
                        customerData: customerResult,
                        userName: unm
                    });
                })
                .catch((err) => { console.log("get view customer err :: ", err); });
        })
        .catch((err) => { console.log("Veiw Error :: ", err); });
};

// GET VIEW SERVICE
// exports.getViewService = (req, res, next) => {

//     Customer.find()
//         .then((customerResult) => {

//             // customerResult.forEach((customer) => {
//             //     console.log("idid :::: ", customer.userId);
//             // })

//             User.findOne({ _id: customerResult.userId })
//                 .then((unm) => {
//                     res.render('viewCustomer', {
//                         pageTitle: "View Customer",
//                         customerData: customerResult,
//                         userName: unm
//                     });
//                 })
//                 .catch((err) => { console.log("get view customer err :: ", err); });
//         })
//         .catch((err) => { console.log("Veiw Error :: ", err); });
// };


// GET EDIT USER
exports.getEditUser = (req, res, next) => {

    User.findById({_id: req.params.u_id})
        .then(userResult => {
            res.render('editUser', {
                pageTitle: "Edit User",
                userData: userResult,
            });
        })
        .catch((err) => { console.log("get edit user err :: ", err) });
};

// POST EDIT USER
exports.postEditUser = (req, res, next) => {
    const { id, name, email, phone, password, dob, city } = req.body;

    
User.findByIdAndUpdate(
    {_id: id}, 
    { $set: { 
        name: name,
        email: email,
        phone: phone,
        password: password,
        dob: dob,
        city: city
    }})
    .then((ress) => {
        res.redirect('/viewUser');
    })
    .catch((err) => { console.log("post edit user err :: ", err) });
};

// GET EDIT CUSTOMER
exports.getEditCustomer = (req, res, next) => {
    res.send("EDIT CUSTOM GET")
};

// POST EDIT CUSTOMER
exports.postEditCustomer = (req, res, next) => {
    res.send("EDIT CUSTOM")
};

// GET EDIT SERVICE
exports.getEditService = (req, res, next) => {
    res.send("EDIT SERVICE GET")
};

// POST EDIT SERVICE
exports.postEditService = (req, res, next) => {
    res.send("EDIT SERVICE")
};


// DELETE USER
exports.postDeleteUser = (req, res, next) => {
    res.send("DLEETED USER");
    User.findByIdAndUpdate()
};

// DELETE CUSTOMER
exports.postDeleteCustomer = (req, res, next) => {
    res.send("DLEETED CUSTOM")
};

// DELETE SERVICE
exports.postDeleteService = (req, res, next) => {
    res.send("DLEETED SERVICE")
};

// GET ADD USER
exports.getAddUser = (req, res, next) => {
    res.render('addUser', {
        pageTitle: "Add User",
    });
};

// POST ADD USER
exports.postAddUser = (req, res, next) => {

    const data = { name, email, phone, password, dob, city } = req.body;
    const user = new User(data);

    user.save()
        .then((ress) => {
            res.render('adminDashboard', {
                pageTitle: "Admin Dashboard",
            });
        })
        .catch((err) => { console.log("Add User err :: ", err) })
};