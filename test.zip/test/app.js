const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path');

const userRoutes = require('./routes/userRoutes');
const app = express();


app.set('view engine', 'ejs');
app.set('views', 'views');

app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, 'public')));

app.use(userRoutes);


mongoose.connect("mongodb://localhost:27017/prac_4")
.then(()=>{
    app.listen(5000, (req, res) => {
        console.log("Server listening on http://localhost:5000");
    })
})
.catch((err) => { console.log(err); });
