const db = require('../util/database');

module.exports = class Operations {

    static save(name) {
        return db.execute("INSERT INTO user (name) VALUES (?)", [name]);
    }

    static fetchAll() {
        return db.execute("SELECT * FROM user");
    }

    static deleteById(id) {
        return db.execute("DELETE FROM user WHERE id = ? ", [id]);
    }

    static  findById(id){
        return db.execute("SELECT * FROM user WHERE id = ? ",[id])
    }

    static updateById(name, id) {
        return db.execute("UPDATE user SET name=? WHERE id = ? ", [name, id]);
    }
}
