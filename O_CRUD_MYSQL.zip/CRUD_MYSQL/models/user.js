const db = require('../util/database');

module.exports = class User {
    constructor(name, email, password, contactNo, dob) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.contactNo = contactNo;
        this.dob = dob;
    }

    save() {
        return db.execute("INSERT INTO user (user_name,user_email,user_password,user_contactNo,user_dob) VALUES (?,?,?,?,?)", [this.name, this.email, this.password, this.contactNo, this.dob]);
    }

    static fetchAll() {
        return db.execute("SELECT * FROM user");
    }

    static deleteById(id) {
        return db.execute("DELETE FROM user WHERE id = ? ", [id]);
    }

    static findById(id) {
        return db.execute("SELECT * FROM user WHERE id = ? ", [id])
    }

    static updateById(name, email, password, contactNo, dob, id) {
        return db.execute("UPDATE user SET user_name=?,user_email=?,user_password=?,user_contactNo=?,user_dob=? WHERE id = ? ", [name, email, password, contactNo, dob, id]);
    }
}