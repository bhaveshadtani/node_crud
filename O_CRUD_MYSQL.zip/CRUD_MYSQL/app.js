const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();

const adminRoutes = require('./routes/adminRoutes');

app.set('view engine','ejs');
app.set('views','views');

app.use(bodyParser.urlencoded({extended : false }));

app.use(adminRoutes);

app.use(express.static(path.join(__dirname,'public')));

console.log('App is Running On 4041');
app.listen(4041);