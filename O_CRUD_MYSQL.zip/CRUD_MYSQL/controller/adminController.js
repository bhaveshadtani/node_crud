const User = require('../models/user');

exports.getIndex = (req, res, next) => {
    res.render('index', {
        path: '/index',
        pageTitle: 'Index'
    });
};

exports.getAddCustomer = (req, res, next) => {
    res.render('add-customer', {
        path: '/add-customer',
        pageTitle: 'Add-Customer'
    });
};
exports.postAddCustomer = (req, res, next) => {
    var name = req.body.name;
    var dob = req.body.dob;
    var email = req.body.email;
    var password = req.body.password;
    var contactNo = req.body.contactNo;

    const user = new User(name, email, password, contactNo, dob);
    user.save()
        .then(() => {
            res.redirect('/display');
        })
        .catch(err => console.log(err))
};

exports.getDisplay = (req, res, next) => {
    User.fetchAll()
        .then(([rows]) => {
            var size = rows.length;

            res.render('display', {
                rows: rows,
                size: size,
                pageTitle: 'Display'
            });
        })
        .catch(err => console.log(err));
};

exports.getUserDelete = (req, res, next) => {
    var id = Number(req.params.id);
    User.deleteById(id)
        .then(() => {
            res.redirect('/display')
        })
        .catch(err => console.log(err));

}

exports.getEditCustomer = (req, res, next) => {
    var id = Number(req.params.id);
    User.findById(id)
        .then(([rows, fieldData]) => {
            res.render('edit-customer', {
                rows: rows[0],
                pageTitle: 'Edit-Customer'
            });
        })
        .catch(err => console.log(err))

}

exports.postCustomerEdit = (req, res, next) => {

    var id = Number(req.body.id);

    var name = req.body.name;
    var dob = req.body.dob;
    var email = req.body.email;
    var password = req.body.password;
    var contactNo = req.body.contactNo;

    User.updateById(name, email, password, contactNo, dob, id)
        .then(() => {
            res.redirect('/display');
        })
        .catch(err => console.log(err))
};