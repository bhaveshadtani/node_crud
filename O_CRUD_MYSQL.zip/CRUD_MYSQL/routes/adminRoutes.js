const express = require('express');

const router = express.Router();

const adminController = require('../controller/adminController.js')


// router.get('/',adminController.getIndex);
router.get('/',adminController.getAddCustomer);
router.get('/add-customer',adminController.getAddCustomer);

router.get('/display',adminController.getDisplay);
// router.post('/display',adminController.postDisplay);

router.post('/add-customer',adminController.postAddCustomer);

router.get('/edit-customer/:id',adminController.getEditCustomer);
// router.get('/edit-customer/:id',adminController.postEditCustomer);
router.post('/edit-customer',adminController.postCustomerEdit);

// router.get('/update/:id',adminController.getUserUpdate);
router.get('/delete/:id',adminController.getUserDelete);


module.exports = router;