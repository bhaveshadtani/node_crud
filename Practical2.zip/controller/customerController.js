const Customer = require('../models/customer_model');

exports.getAdd_Customer = (req, res, next) => {
    res.render('add_customer_view', {
        pageTitle: 'Add Customer'
    });
};

exports.postRegister_Customer = (req, res, next) => {
    var name = req.body.name;
    var email = req.body.email;
    var phone = req.body.phone;
    var dob = req.body.dob;
    var password = req.body.password;
    var c_password = req.body.c_password;
    var country = req.body.country;
    var address = req.body.address;

    Customer.save(name, email, phone, dob, password, c_password, country, address)
        .then(() => {
            res.redirect('/add_Customer');
        })
        .catch(err => console.log(err))
};

exports.getDisp_Customer = (req, res, next) => {
    Customer.fetchAll()
        .then(([rows]) => {
            var size = rows.length;

            res.render('disp_customer_view', {
                rows: rows,
                size: size,
                pageTitle: 'Display Customer'
            })
        })
        .catch(err => console.log(err));
};

exports.getDelete_Customer = (req, res, next) => {
    var id = Number(req.params.id);

    Customer.deleteById(id)
        .then(() => {
            res.redirect('/disp_Customer')
        })
        .catch(err => console.log(err));

}

exports.getEdit_Customer = (req, res, next) => {
    var id = Number(req.params.id);

    Customer.findById(id)
    .then(([rows]) => {
        res.render('edit_customer_view', {
            rows: rows[0],
            pageTitle: 'Edit Customer'
        });
    })
    .catch(err => console.log(err))

}

exports.postUpdate_Customer = (req, res, next) => {
    var id = Number(req.body.id);
    var name = req.body.name;
    var email = req.body.email;
    var phone = req.body.phone;
    var dob = req.body.dob;
    var country = req.body.country;
    var address = req.body.address;

    Customer.updateById(name, email, phone, dob, country, address, id)
        .then(() => {
            res.redirect('/disp_Customer');
        })
        .catch(err => console.log(err))
};