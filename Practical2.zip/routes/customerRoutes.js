const express = require('express');

const router = express.Router();

const customerController = require('../controller/customerController.js')


// FOR ROOT DIRECTORY ('/')
router.get('/',customerController.getAdd_Customer);

// NAV LINK ADD CUSTOMER
router.get('/add_Customer',customerController.getAdd_Customer);

// NAV LINK DISPLAY CUSTOMER
router.get('/disp_Customer',customerController.getDisp_Customer);

// ON REGISTER(BUTTON) FROM ADD CUSTOMER PAGE
router.post('/register_Customer',customerController.postRegister_Customer);

// CUSTOMER DISPLAY EDIT BUTTON TO OPEN EDIT FORM
router.get('/edit_Customer/:id',customerController.getEdit_Customer);

// 
router.post('/update_Customer',customerController.postUpdate_Customer);

// 
router.get('/delete_Customer/:id',customerController.getDelete_Customer);


module.exports = router;