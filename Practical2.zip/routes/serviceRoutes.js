const express = require('express');

const router = express.Router();

const serviceController = require('../controller/serviceController.js')


// NAV LINK ADD SERVICE
router.get('/add_Service',serviceController.getAdd_Service);

// NAV LINK DISPLAY SERVICE
router.get('/disp_Service',serviceController.getDisp_Service);

// ON REGISTER FROM ADD SERVICE PAGE
router.post('/register_Service',serviceController.postRegister_Service);

// SERVICE DISPLAY EDIT BUTTON TO OPEN EDIT FORM
router.get('/edit_Service/:id',serviceController.getEdit_Service);

// UPDATE FORM DATA
router.post('/update_Service',serviceController.postUpdate_Service);

// DELETE
router.get('/delete_Service/:id', serviceController.getDelete_Service)

module.exports = router;