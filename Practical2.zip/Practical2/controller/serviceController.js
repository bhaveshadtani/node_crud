const Service = require('../models/service_model');

exports.getAdd_Service = (req, res, next) => {

    Service.getDropDownVals()
    .then((dropDown) => {
        console.log("cusrtomer",dropDown);
        res.render('add_service_view', {
            pageTitle: 'Add Service',
            dropdownVals: dropDown
        });
    }).catch(err => console.log(err));

    // res.render('add_service_view', {
    //             pageTitle: 'Add Service',
    //         });
};
exports.postRegister_Service = (req, res, next) => {
    var customer_name = req.body.customer_name;
    var vehical_no = req.body.vehical_no;
    var pickUp_date = req.body.pickUp_date;
    var drop_date = req.body.drop_date;
    var location = req.body.location;
    var service_location = req.body.service_location;
    var service_price = req.body.service_price;
    var payable_amount = req.body.payable_amount;

    Service.save(customer_name, vehical_no, pickUp_date, drop_date, location, service_location, service_price, payable_amount)
        .then(() => {
            res.redirect('/add_Service');
        })
        .catch(err => console.log(err))
};

exports.getDisp_Service = (req, res, next) => {

    Service.fetchAll()
        .then(([rows]) => {
            var size = rows.length;

            res.render('disp_service_view', {
                rows: rows,
                size: size,
                pageTitle: 'Display Service'
            })
        })
        .catch(err => console.log(err));
};

exports.getDelete_Service = (req, res, next) => {
    var id = Number(req.params.id);
    Service.deleteById(id)
        .then(() => {
            res.redirect('/disp_Service');
        })
        .catch(err => console.log(err));
}

exports.getEdit_Service = (req, res, next) => {
    var id = Number(req.params.id);
    Service.findById(id)
        .then(([rows]) => {
            res.render('edit_service_view', {
                rows: rows[0],
                pageTitle: 'Edit Service'
            });
        })
        .catch(err => console.log(err))

}

exports.postUpdate_Service = (req, res, next) => {

    var id = Number(req.body.id);

    var customer_name = req.body.customer_name;
    var vehical_no = req.body.vehical_no;
    var pickUp_date = req.body.pickUp_date;
    var drop_date = req.body.drop_date;
    var location = req.body.location;
    var service_price = req.body.service_price;
    var payable_amount = req.body.payable_amount;

    Service.updateById(customer_name, vehical_no, pickUp_date, drop_date, location, service_price, payable_amount, id)
        .then(() => {
            res.redirect('/disp_Service');
        })
        .catch(err => console.log(err))
};