const db = require('../util/database');

module.exports = class Customer {

    static save(name, email, phone, dob, password, c_password, country, address) {
        return db.execute("INSERT INTO customer (name, email, phone, dob, password, country, address, c_isActive) VALUES (?,?,?,?,?,?,?,?)", [name, email, phone, dob, password, country, address, 1]);
    }

    static fetchAll() {
        return db.execute("SELECT * FROM customer WHERE c_isActive = 1");
    }

    static deleteById(id) {
        return db.execute("UPDATE customer SET c_isActive = 0 WHERE c_id = ? ", [id]);
    }

    static  findById(id){
        return db.execute("SELECT * FROM customer WHERE c_id = ? ",[id])
    }

    static updateById(name, email, phone, dob, country, address, id) {
        return db.execute("UPDATE customer SET name=?, email=?, phone=?, dob=?, country=?, address=? WHERE c_id = ? ", [name, email, phone, dob, country, address, id]);
    }
}