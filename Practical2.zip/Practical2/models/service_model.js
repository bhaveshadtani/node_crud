const db = require('../util/database');

module.exports = class Service {

    static getDropDownVals(){
        return db.execute("SELECT c_id,name FROM customer WHERE c_isActive = 1");
    }

    static save(customer_name, vehical_no, pickUp_date, drop_date, location, service_location, service_price, payable_amount) {
        return db.execute("INSERT INTO service (customer_name, vehical_no, pickUp_date, drop_date, location, service_location, price, payable_amount, s_isActive) VALUES (?,?,?,?,?,?,?,?,?)", [customer_name, vehical_no, pickUp_date, drop_date, location, service_location, service_price, payable_amount, 1]);
    }

    static fetchAll() {
        return db.execute("SELECT * FROM service WHERE s_isActive = 1");
    }

    static deleteById(id) {
        return db.execute("UPDATE service SET s_isActive = 0 WHERE s_id = ? ", [id]);
    }

    static  findById(id){
        return db.execute("SELECT * FROM service WHERE s_id = ? ",[id])
    }

    static updateById(customer_name, vehical_no, pickUp_date, drop_date, location, price, payable_amount, id) {
        return db.execute("UPDATE service SET customer_name=?, vehical_no=?, pickUp_date=?, drop_date=?, location=?, price=?, payable_amount=? WHERE s_id = ? ", [customer_name, vehical_no, pickUp_date, drop_date, location, price, payable_amount, id]);
    }
}