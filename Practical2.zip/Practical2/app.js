const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();

const customerRoutes = require('./routes/customerRoutes');
const serviceRoutes = require('./routes/serviceRoutes');

app.set('view engine','ejs');
app.set('views','views');

app.use(bodyParser.urlencoded({extended : false }));
app.use(express.static(path.join(__dirname,'public')));

app.use(customerRoutes);
app.use(serviceRoutes);

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000/");
});